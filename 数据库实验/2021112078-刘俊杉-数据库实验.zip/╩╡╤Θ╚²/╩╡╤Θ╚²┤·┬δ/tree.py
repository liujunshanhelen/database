class Tree:
    def __init__(self):
        self.left_child = None
        self.right_child = None
        self.operator = ''
        self.context = ''
        self.attribute = ''
