import write
def qq():
    write.write(str(0))

if __name__ == '__main__':
    qq()
